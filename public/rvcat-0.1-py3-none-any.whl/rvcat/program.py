import json

global _program

def _fraction(value, default):
    # number in [0, 1], or default when missing or invalid
    try:
        if value is None or (isinstance(value, str) and not value.strip()):
            return default
        return min(1.0, max(0.0, float(value)))
    except (TypeError, ValueError):
        return default

class Instruction:

    def __init__(self) -> None:
        self.type     = ""
        self.oper     = ""
        self.size     = ""
        self.text     = ""
        self.destin   = ""
        self.source1  = ""
        self.source2  = ""
        self.source3  = ""
        self.mask     = ""   # masked vector store: variable with the mask (only the true lanes are written)
        self.constant = ""
        self.stride   = 1
        self.lanes    = 1
        self.latency  = 0
        self.ports    = 0
        self.addr     = 0    # value initialized when program is loaded
        self.byte_stride = 4 # value initialized when program is loaded
        self.prob     = 0.5  # conditional branch ("if c skip k"): probability of being taken
        self.mispredict = None # conditional branch: misprediction rate (None: 2-bit predictor)

    def from_json(data: dict):
        instr = Instruction()
        instr.oper       = data.get("oper", "")
        instr.type       = data.get("type", "")
        instr.size       = data.get("size", "")
        instr.text       = data.get("text", "")
        instr.destin     = data.get("destin", "")
        instr.source1    = data.get("source1", "")
        instr.source2    = data.get("source2", "")
        instr.source3    = data.get("source3", "")
        instr.mask       = data.get("mask", "") or ""
        instr.constant   = data.get("constant", "")
        instr.lanes      = data.get("lanes", 1)
        instr.stride     = data.get("stride", 1)
        instr.addr       = data.get("addr", 0)
        instr.byte_stride= data.get("byte_stride", 4)
        instr.prob       = _fraction(data.get("prob"), 0.5)
        instr.mispredict = _fraction(data.get("mispredict"), None)
        instr.latency    = data.get("latency", 0)
        instr.ports      = data.get("ports", 0)
        return instr

    def json(self) -> dict:
        return {
            "type":     self.type,
            "oper":     self.oper,
            "size":     self.size,
            "text":     self.text,
            "destin":   self.destin,
            "source1":  self.source1,
            "source2":  self.source2,
            "source3":  self.source3,
            "mask":     self.mask,
            "constant": self.constant,
            "lanes":    self.lanes,
            "stride":   self.stride,
            "latency":  self.latency,
            "ports":    self.ports,
            "addr":     self.addr,
            "byte_stride": self.byte_stride,
            "prob":     self.prob,
            "mispredict": self.mispredict
        }
    
class Process:

    def __init__(self) -> None:
        self.name     = ""
        self.Nloop    = 16      # number of loop iterations (not unrolled)
        self.dispatch = 1       # dispatch width (number of instructions dispatched per cycle)
        self.retire   = 1       # retire width (number of instructions retired per cycle)
        self.ROBsize  = 20      # size of the Reorder Buffer (ROB) in number of instructions
        self.sched   = "greedy" # scheduling policy
        self.nBlocks    = 0     # number of L1 cache blocks (in bytes) 
        self.blkSize    = 16    # L1 cache block size (in bytes); unit for memory accesses
        self.mIssueTime = 1     # memory issue time (in cycles) for a MM request (load/store)
        self.mPenalty   = 1     # memory penalty (latency in cycles) for a cache miss
        self.nFillBuffers = 2   # maximum number of concurrent cache-block fills
        self.nWriteBuffers = 2 # maximum number of pending dirty-block writebacks
        self.rThru = 1          # maximum number of LOADs that receive their data from the fill buffers per cycle
        self.nStoreBuffers = 16 # entries of the store buffer (stores from dispatch until written into the cache)
        self.bPenalty = 5       # cycles to refill the front-end after a mispredicted branch resolves
        self.speculation = "stall"  # simulation option: "stall" or "wrong-path" after a misprediction
        self.rep = 1            # repetitions of the whole loop (calls of the function)
        self.repIndependent = True  # the repetitions do not use the results of the previous one: they can overlap
        self.repStrides = {}    # array name -> elements that its accesses advance in each repetition (0: same data)
        self.forceDynamic = False   # (tests) simulate with the dynamic dispatch even without repetitions or branches
        self.epilogue = []      # instructions executed once after each call of the loop (same format)
        self.instruction_list = []      # list of instructions in the program (in program order)
        
    def from_json(data: dict):
        process = Process()
        process.name             = data.get("name", "")
        process.Nloop            = data.get("Nloop", 16)   # default number of loop iterations (power of 2)
        process.dispatch         = data.get("dispatch", 1)
        process.retire           = data.get("retire", 1)
        process.ROBsize          = data.get("ROBsize", 20)
        process.sched            = data.get("sched", "greedy")
        process.nBlocks          = data.get("nBlocks", 0)
        process.blkSize          = data.get("blkSize", 16)
        process.mPenalty         = data.get("mPenalty", 1) 
        process.mIssueTime       = data.get("mIssueTime", 1)
        process.nFillBuffers     = data.get("nFillBuffers", 2)
        process.nWriteBuffers    = data.get("nWriteBuffers", 2)
        process.rThru            = data.get("rThru", 1)
        process.nStoreBuffers    = data.get("nStoreBuffers", 16)
        process.bPenalty         = data.get("bPenalty", 5)
        process.speculation      = data.get("speculation", "stall")
        if process.speculation not in ("stall", "wrong-path"):
            raise ValueError("speculation must be 'stall' or 'wrong-path'.")
        if isinstance(process.bPenalty, bool) or not isinstance(process.bPenalty, int) or \
                not 0 <= process.bPenalty <= 99:
            raise ValueError("bPenalty must be an integer between 0 and 99.")
        if process.mPenalty < process.mIssueTime:
            raise ValueError("mPenalty must be greater than or equal to mIssueTime.")
        if isinstance(process.rThru, bool) or not isinstance(process.rThru, int) or \
                not 1 <= process.rThru <= 32:
            raise ValueError("rThru must be an integer between 1 and 32.")
        if isinstance(process.nStoreBuffers, bool) or not isinstance(process.nStoreBuffers, int) or \
                not 1 <= process.nStoreBuffers <= 256:
            raise ValueError("nStoreBuffers must be an integer between 1 and 256.")
        process.rep              = data.get("rep", 1)
        process.repIndependent   = data.get("repIndependent", True)
        process.repStrides       = data.get("repStrides", {}) or {}
        process.forceDynamic     = bool(data.get("forceDynamic", False))
        process.epilogue         = data.get("epilogue", []) or []
        if not isinstance(process.epilogue, list):
            raise ValueError("epilogue must be a list of instructions.")
        if isinstance(process.rep, bool) or not isinstance(process.rep, int) or not 1 <= process.rep <= 50000:
            raise ValueError("rep must be an integer between 1 and 50000.")
        if not isinstance(process.repIndependent, bool):
            raise ValueError("repIndependent must be true or false.")
        if not isinstance(process.repStrides, dict) or any(
                isinstance(v, bool) or not isinstance(v, int) or v < 0 for v in process.repStrides.values()):
            raise ValueError("repStrides must map array names to integers >= 0.")
        process.instruction_list = data.get("instruction_list", [])
        return process

    def json(self) -> dict:
        return {
            "name":             self.name,
            "Nloop":            self.Nloop,
            "dispatch":         self.dispatch,
            "retire":           self.retire,
            "ROBsize":          self.ROBsize,
            "sched":            self.sched,
            "nBlocks":          self.nBlocks,
            "blkSize":          self.blkSize,
            "mPenalty":         self.mPenalty,
            "mIssueTime":       self.mIssueTime,
            "nFillBuffers":     self.nFillBuffers,
            "nWriteBuffers":    self.nWriteBuffers,
            "nStoreBuffers":    self.nStoreBuffers,
            "rThru":            self.rThru,
            "bPenalty":         self.bPenalty,
            "speculation":      self.speculation,
            "rep":              self.rep,
            "repIndependent":   self.repIndependent,
            "repStrides":       self.repStrides,
            "epilogue":         self.epilogue,
            "instruction_list": self.instruction_list
        }

class Program:

    def __init__(self) -> None:

        # data loaded/stored which do not change during execution
        self.n                = 0       # number of instructions in the program
        self.instruction_list = []      # list of instructions in the program (in program order)
        self.epilogue         = []      # instructions executed after each call of the loop (simulation)

        # data generated when loading a new program. Do not need to save it
        self.variables    = [] # variable names (each appears only once, in program order)
        self.constants    = [] # constant values/variable names (only once, program order)
        self.read_only    = [] # list of read-only variable names (only once)
        self.loop_carried = [] # list of tuples of loop-carried variables: (producer_id,var_name)
        self.arrays       = [] # list of array variable names in program order

        self.inst_dependence_list = []  # list of instruction data dependencies
        self.dependence_edges     = []  # list of dependence offsets
        self.cyclic_paths         = []  # list of cyclic paths (a list of inst_ids)
        self.inst_cyclic          = []  # list of inst_ids in cyclic paths (only once)

    def __getitem__(self, i: int):
        if self.epilogue and i >= self.n:      # an instruction of the block after each call
            return self.epilogue[i - self.n]
        return self.instruction_list[i%self.n]

    # The block of instructions executed after each call of the loop (only for the simulation: the
    # static analysis is about the loop). Its arrays are added to the arrays of the loop.
    def load_epilogue(self, instrs) -> None:
        self.epilogue = [Instruction.from_json(d) for d in (instrs or [])]
        for inst in self.epilogue:
            if inst.type in ("MEM", "VMEM") and inst.source2 and inst.source2 not in self.arrays:
                self.arrays.append(inst.source2)
                self.array_addrs.append(0)

    # Load JSON object containing program specification
    def load_instruction_list(self, instrs) -> None:

        self.instruction_list = []
        for instr_dict in instrs:
            self.instruction_list.append(Instruction.from_json(instr_dict))
        self.epilogue     = []
        self.n            = len(self.instruction_list)
        self.loop_stride  = 1  # by default, loop stride is 1
        self.variables    = [] # variable names (each appears only once, in program order)
        self.constants    = [] # constant values/variable names (only once, program order)
        self.loop_carried = [] # index to list of variable names which are loop-carried
        self.read_only    = [] # index to list of variable names which are read-only
        self.arrays       = [] # list of array variable names in program order
        self.array_addrs  = [] # list of initial memory addresses for arrays in program order

        self.inst_dependence_list = []  ## list of instruction data dependencies
        # inst_dependence_list = [ i0, i1, i2 ... ]; 
        #       i0 = [ dep0, dep1, ...];   List of input dependencies, from 0 to 3
        #     dep0 = [ instID, varID / constID]; 
        #   instID = 0 to N-1  index of instruction generating input value
        #    varID = 0 to K-1  index of variable name representing input value
        #   instID = -1  means input value is constant
        #   instID = -3  means input value is read-only variable
        #  constID = 0 to C-1  index to constant name representing input constant

        Outs    = [] ## List of output variable names in program's instruction order
        Reads1  = [] ## List of  first input variable names in program's instruction order
        Reads2  = [] ## List of second input variable names in program's instruction order
        Reads3  = [] ## List of third output variable names in program's instruction order
        Reads4  = [] ## List of masks (masked stores) in program's instruction order
        Consts  = [] ## List of constants in program's instruction order

        for inst in self.instruction_list:
            Outs.append  (inst.destin)
            Consts.append(inst.constant)
            Reads1.append(inst.source1)
            Reads2.append(inst.source2)
            Reads3.append(inst.source3)
            Reads4.append(inst.mask)

        # List of variable names that are output of an instruction (appears only once)
        Outputs = list(set(Outs))  
        if "" in Outputs:
          Outputs.remove("")

        # List of variable names that are input of an instruction (appears only once)
        Inputs = list(set(Reads1+Reads2+Reads3+Reads4))  
        if "" in Inputs:
          Inputs.remove("")

        # List of variable names (each appears only once, in program order)
        self.variables = list(set(Outputs+Inputs))
        if "" in self.variables:
          self.variables.remove("")

        # List of constant values / variable names (each appears only once)
        self.constants = list(set(Consts))
        if "" in self.constants:
          self.constants.remove("")
       
        # remove constants which are already a variable (this should not happen)
        setVars = set(self.variables)
        index = 0
        for c in self.constants:
          if c in setVars:
             self.constants.pop(index)
          else:
            index += 1

        # initialize list of producers for each variable as NONE
        producer_list = [-2 for _ in range(len(Outputs))]

        # analyze all instructions in program order to generate dependence info
        for inst_id in range(self.n):

            # create dependence list for intruction inst_id and append to program's dependence list
            dep_list = [] 
            self.inst_dependence_list.append(dep_list)

            const = Consts[inst_id]
            if const:  # register usage of this constant
                dep = [-1, self.constants.index(const)]
                dep_list.append(dep)

            source_var = Reads1[inst_id]
            if source_var:  # register dependence on this variable
                var_idx = self.variables.index(source_var)
                if source_var in Outputs:
                    out_idx  = Outputs.index(source_var)
                    prod_idx = producer_list[out_idx]
                else:  # read-only variable: acts as if it is a constant value
                    prod_idx = -3
                    self.read_only.append(source_var)
                dep = [prod_idx, var_idx]
                dep_list.append(dep)

            source_var = Reads2[inst_id]
            if source_var:  # register dependence on this variable
                var_idx = self.variables.index(source_var)
                if source_var in Outputs:
                    out_idx  = Outputs.index(source_var)
                    prod_idx = producer_list[out_idx]
                else:  # read-only variable: acts as if it is a constant value
                    prod_idx = -3
                    self.read_only.append(source_var)
                dep = [prod_idx, var_idx]
                dep_list.append(dep)

            source_var = Reads3[inst_id]
            if source_var:  # register dependence on this variable
                var_idx = self.variables.index(source_var)
                if source_var in Outputs:
                    out_idx  = Outputs.index(source_var)
                    prod_idx = producer_list[out_idx]
                else:  # read-only variable: acts as if it is a constant value
                    prod_idx = -3
                    self.read_only.append(source_var)
                dep = [prod_idx, var_idx]
                dep_list.append(dep)

            source_var = Reads4[inst_id]
            if source_var and source_var not in (Reads1[inst_id], Reads2[inst_id], Reads3[inst_id]):
                var_idx = self.variables.index(source_var)    # mask of a masked store
                if source_var in Outputs:
                    out_idx  = Outputs.index(source_var)
                    prod_idx = producer_list[out_idx]
                else:
                    prod_idx = -3
                    self.read_only.append(source_var)
                dep_list.append([prod_idx, var_idx])

            output_var = Outs[inst_id]
            if output_var:  # modify producer of this variable
                out_idx = Outputs.index(output_var)
                producer_list[out_idx] = inst_id

        # analyze all instructions in program order to solve loop-carried dependencies
        for inst_id in range(self.n):
            # obtain dependence list for intruction inst_id
            dep_list = self.inst_dependence_list[inst_id]
            for dep in dep_list:
                if dep[0] == -2: # dependence is pending to solve
                    source_var= self.variables[ dep[1] ]
                    out_idx   = Outputs.index(source_var)
                    prod_idx  = producer_list[out_idx]
                    dep[0] = prod_idx
                    self.loop_carried.append( (prod_idx, source_var) )

        # List of read-only variable names (each appears only once, in program order)
        self.read_only    = list(set(self.read_only))

        # List of tuples of loop-carried (producer, variable name) each appears only once
        self.loop_carried = list(set(self.loop_carried))

        self.generate_dependence_info()
        self.get_cyclic_paths()

        Insts = []
        for cyc_path in self.cyclic_paths:
          for iID in cyc_path:
            Insts.append  (iID)

        self.inst_cyclic = list(set(Insts))  
        # list of inst_ids in cyclic paths (only once)

        self.collect_arrays()

    # ------------------------------------------------------------------------------------------
    # Conditional forward branches inside the loop body: "if c skip k" (type BRANCH, constant k)
    # ------------------------------------------------------------------------------------------
    def conditional_branches(self):
        # [(index, k)]: the branch at index skips the next k instructions when it is taken
        out = []
        for i, inst in enumerate(self.instruction_list[:-1]):
            if inst.type == "BRANCH":
                try:
                    k = int(str(inst.constant).strip() or 1)
                except ValueError:
                    k = 1
                out.append((i, max(1, min(k, self.n - 2 - i))))
        return out

    def execution_paths(self, max_paths=4096):
        # Paths of one iteration: [(probability, [executed instruction indices])]
        skips = dict(self.conditional_branches())
        paths = []

        def walk(i, prob, executed):
            if len(paths) >= max_paths:
                return
            while i < self.n:
                executed = executed + [i]
                if i in skips:
                    p = self.instruction_list[i].prob
                    if p > 0:
                        walk(i + 1 + skips[i], prob * p, executed)
                    if p < 1:
                        walk(i + 1, prob * (1 - p), executed)
                    return
                i += 1
            paths.append((prob, executed))

        walk(0, 1.0, [])
        return paths

    def execution_probabilities(self):
        # probability that each instruction is executed in an iteration
        probs = [0.0] * self.n
        for prob, executed in self.execution_paths():
            for i in executed:
                probs[i] += prob
        return probs

    def resolution_latency(self, i):
        # Cycles from the start of an iteration until instruction i can finish, following the
        # data dependences inside the iteration (producers written earlier in the same iteration;
        # loop-carried values are assumed ready). For a conditional branch: an approximation of
        # the time until it resolves, during which the instructions that follow it are not useful.
        depth = {}
        for j in range(i + 1):
            ready = max((depth[p] for p, _ in self.inst_dependence_list[j] if 0 <= p < j), default=0)
            depth[j] = ready + self.instruction_list[j].latency
        return depth[i]

    def _written_variables(self):
        return {inst.destin for inst in self.instruction_list + self.epilogue if inst.destin}

    def read_variables(self, i):
        # variables read by instruction i that some instruction writes (data dependences)
        # (i >= n: an instruction of the block after each call)
        written = self._written_variables()
        inst = self[i] if i >= self.n else self.instruction_list[i]
        out = []
        for v in (inst.source1, inst.source2, inst.source3, inst.mask):
            if v and v in written and v not in out:
                out.append(v)
        return out

    def producer_alternatives(self, max_distance=3):
        # {(consumer, variable): [(producer, iteration distance, probability)]}
        # A consumer may have several producers when a conditional block can skip them.
        paths = self.execution_paths()
        written = self._written_variables()
        # last writer of each variable in a whole iteration: {var: {producer or None: prob}}
        last_in_iter = {v: {} for v in written}
        for prob, executed in paths:
            for v in written:
                w = next((i for i in reversed(executed) if self.instruction_list[i].destin == v), None)
                last_in_iter[v][w] = last_in_iter[v].get(w, 0.0) + prob
        alternatives = {}
        for j in range(self.n):
            for v in self.read_variables(j):
                dist = {}
                none_mass = 0.0
                for prob, executed in paths:
                    if j not in executed:
                        continue
                    before = executed[:executed.index(j)]
                    w = next((i for i in reversed(before) if self.instruction_list[i].destin == v), None)
                    if w is None:
                        none_mass += prob
                    else:
                        dist[(w, 0)] = dist.get((w, 0), 0.0) + prob
                for d in range(1, max_distance + 1):
                    if none_mass <= 1e-12:
                        break
                    for w, pw in last_in_iter[v].items():
                        if w is not None:
                            dist[(w, d)] = dist.get((w, d), 0.0) + none_mass * pw
                    none_mass *= last_in_iter[v].get(None, 0.0)
                total = sum(dist.values())
                if total > 0:
                    alternatives[(j, v)] = sorted(((w, d, p / total) for (w, d), p in dist.items()),
                                                  key=lambda x: (x[1], -x[0]))
        return alternatives

    @staticmethod
    def predictor_misprediction_rate(p, samples=20000, seed=12345):
        # misprediction rate of a 2-bit saturating counter when the branch is taken with
        # probability p, independently in each execution
        import random
        rng = random.Random(seed)
        counter, misses = 1, 0
        for _ in range(samples):
            taken = rng.random() < p
            if (counter >= 2) != taken:
                misses += 1
            counter = min(3, counter + 1) if taken else max(0, counter - 1)
        return misses / samples

    def collect_arrays(self) -> None:
        # get list of array variables in program order, and the loop stride (BRANCH stride)
        self.loop_stride = 1
        Arrays = []
        for inst in self.instruction_list:
            if inst.type == "MEM" or inst.type == "VMEM":
              ArrayName = inst.source2
              Arrays.append  (ArrayName)
            elif inst.type == "BRANCH":  # if stride is not 1, then it defines the loop counter stride
              if inst.stride != 1:
                self.loop_stride= inst.stride

        # Eliminar duplicados preservando orden y filtrar strings vacíos en un solo paso
        self.arrays = list(dict.fromkeys(filter(None, Arrays)))
        self.array_addrs = [0] * len(self.arrays)

    def assign_memory_addresses(self, N: int, reps: int = 1, rep_strides=None) -> None:
        # With repetitions of the loop (reps > 1), the accesses to an array advance rep_strides[array]
        # elements in each repetition (inst.rep_byte_stride), and the array includes all of them.
        rep_strides = rep_strides or {}
        # assign initial memory addresses and byte-stride to load/store instructions, 
        # for use in memory trace generation
        # for simplicity, we assign addresses to all array names in program order, starting from 0
        # accesses to an array determin the arrays size
        
        iterations = N // self.loop_stride  # number of loop iterations to execute

        self.array_addrs = []
        init_addr = 0
        for arrayName in self.arrays:
            array_size = 0
            dataSize = 0
            for inst in self.instruction_list + self.epilogue:
                if inst.type == "MEM" or inst.type == "VMEM":
                    if arrayName == inst.source2 and inst in self.epilogue:   # once per call
                        const = 0 if inst.constant == "" else int(inst.constant)
                        dataSize = 4 if inst.size == "word" else (8 if inst.size == "long" else 1)
                        inst.byte_stride = 0
                        inst.addr = init_addr + const*dataSize
                        array_size = max(array_size, (const + inst.lanes)*dataSize)
                    elif (arrayName == inst.source2):
                        const = 0 if inst.constant == "" else int(inst.constant)
                        dataSize = 4 if inst.size == "word" else (8 if inst.size == "long" else 1)
                        inst.byte_stride = dataSize*inst.lanes*inst.stride
                        if inst.stride < 0: # if stride is negative, then it is a reverse access starting from the end of the array
                           inst.addr = init_addr + (N-const)*dataSize
                           last_addr = inst.addr + (iterations-1)*inst.byte_stride
                           array_size = max(array_size, inst.addr+dataSize*inst.lanes-init_addr)
                        elif inst.stride > 0:  # if stride is positive, then it is a forward access starting from the beginning of the array
                           inst.addr = init_addr + const*dataSize
                           last_addr = inst.addr + (iterations-1)*inst.byte_stride
                           array_size = max(array_size, last_addr+dataSize*inst.lanes-init_addr)
                        else:  # if stride is zero, then it is an offset starting from the beginning of the array
                           inst.addr = init_addr + const*dataSize
                           last_addr = inst.addr + inst.byte_stride
                           array_size = max(array_size, last_addr+dataSize*inst.lanes-init_addr)

            rep_bytes = rep_strides.get(arrayName, 0) * dataSize
            for inst in self.instruction_list + self.epilogue:
                if (inst.type == "MEM" or inst.type == "VMEM") and inst.source2 == arrayName:
                    inst.rep_byte_stride = rep_bytes
            array_size += (reps - 1) * rep_bytes   # the data of the other repetitions follow
            self.array_addrs.append([init_addr, dataSize, array_size])
            init_addr += array_size  # assign next array to the next free address after current array

    def get_memory_trace(self, programJSON, N: int, K: int = 4) -> str:
        # Memory addresses accessed by the program during the first K and the last K loop
        # iterations, with the same model used by the simulator (assign_memory_addresses and
        # the per-iteration increment of the scheduler). N = algorithmic operations; the loop
        # runs N // S iterations (S = loop stride). Uses its own Program object, so the state
        # of the loaded program is not modified.
        # With repetitions of the loop (programJSON rep > 1), the 1st and the 2nd calls are shown:
        # in call r, the accesses to an array advance r * repStrides[array] elements; the block
        # after each call (epilogue) is accessed once per call.
        #   arrays:   [{name, base, elem_size, bytes}]          (program order)
        #   rows:     [{rep, k}]                                (call and iteration of each row)
        #   accesses: [{index, array, oper, size, lanes, stride, constant, rep_stride,
        #               addr: [...], elem: [...]}]            (one value per row)
        #   epilogue: [{index, array, oper, size, lanes, constant, rep_stride,
        #               addr: [...], elem: [...]}]            (one value per shown call)
        prog = Program()
        prog.instruction_list = [Instruction.from_json(d) for d in programJSON.get("instruction_list", [])]
        prog.n = len(prog.instruction_list)
        prog.collect_arrays()
        prog.load_epilogue(programJSON.get("epilogue", []))
        reps        = max(1, int(programJSON.get("rep", 1) or 1))
        rep_strides = {a: int(v) for a, v in (programJSON.get("repStrides") or {}).items()}
        S = prog.loop_stride
        N = max(S, N - N % S)
        prog.assign_memory_addresses(N, reps, rep_strides)
        iterations = N // S
        K = max(1, K)
        shown = sorted(set(range(min(K, iterations))) | set(range(max(0, iterations - K), iterations)))
        calls = [0, 1] if reps > 1 else [0]
        rows  = [{"rep": r, "k": k} for r in calls for k in shown]

        arrays = [{"name": name, "base": base, "elem_size": size, "bytes": total}
                  for name, (base, size, total) in zip(prog.arrays, prog.array_addrs)]

        def access(index, inst, addrs, prob=None):
            base     = prog.array_addrs[prog.arrays.index(inst.source2)][0]
            dataSize = 4 if inst.size == "word" else (8 if inst.size == "long" else 1)
            out = {"index": index, "array": inst.source2, "oper": inst.oper, "size": dataSize,
                   "lanes": inst.lanes, "stride": inst.stride, "constant": inst.constant,
                   "rep_stride": rep_strides.get(inst.source2, 0),
                   "addr": addrs, "elem": [(a - base) // dataSize for a in addrs]}
            if prob is not None:
                out["exec_prob"] = prob
            return out

        def is_access(inst):
            return inst.type in ("MEM", "VMEM") and inst.source2 in prog.arrays

        accesses = []
        exec_probs = prog.execution_probabilities() if prog.conditional_branches() else [1.0] * prog.n
        for index, inst in enumerate(prog.instruction_list):
            if is_access(inst):
                addrs = [inst.addr + row["k"] * inst.byte_stride + row["rep"] * inst.rep_byte_stride for row in rows]
                accesses.append(access(index, inst, addrs, exec_probs[index]))
        epilogue = [access(prog.n + j, inst, [inst.addr + r * inst.rep_byte_stride for r in calls])
                    for j, inst in enumerate(prog.epilogue) if is_access(inst)]

        return json.dumps({"N": N, "S": S, "iterations": iterations, "shown": shown,
                           "rep": reps, "calls": calls, "rows": rows,
                           "arrays": arrays, "accesses": accesses, "epilogue": epilogue})

    def generate_dependence_info (self) -> None:

        # Used by execution scheduler to control data dependencies during execution
        # For each static instruction, list of dependent offsets 
        # offset = positive number to subtract to my instruction ID to find dependent intr. ID

        self.dependence_edges = []  

        for inst_id in range(self.n):
            offsets = []
            for dep in self.inst_dependence_list[inst_id]:
                dep_id = dep[0]  # ID of instruction providing data to instruction inst_id
                if dep_id >= 0:  # is a data dependence
                  if dep_id >= inst_id: # loop carried dependence
                    offset = inst_id - dep_id + self.n
                  else:
                    offset = inst_id - dep_id
                  offsets.append(offset)

            self.dependence_edges.append(offsets)

    def get_cyclic_paths(self) -> None:

        # return list of cyclic dependence paths: [[3, 3], [2, 0, 2]],
        # numbers are instr-IDs: same ID appears at begin & end

        start_instrs = []

        for inst_id in range(self.n):
            some_prev_dependence = False
            for dep in self.inst_dependence_list[inst_id]:
                if (dep[0] >= 0) and (dep[0] < inst_id):
                    some_prev_dependence = True
            if not some_prev_dependence:
                start_instrs.append(inst_id)

        # dependency graph in reverse order: from producer to consumer
        dependency_graph = {i:[] for i in range(self.n)}
        for inst_id in range(self.n):
            for dep in self.inst_dependence_list[inst_id]:
                if (dep[0] >= 0):
                    dependency_graph[dep[0]].append(inst_id)

        cyc_paths = []
        paths     = [ [i]  for i in start_instrs]
        visited   = { i:[] for i in range(self.n)}

        while paths:
            path = paths.pop()
            last = path[-1]
            for dep_id in dependency_graph[last]:
                if dep_id not in visited[last]:
                    paths.append(path+[dep_id])
                    visited[last].append(dep_id)
                else:
                    if len(set(path)) != len(path):  # some inst_id appears twice
                        path = path[path.index(last):]
                        if path not in cyc_paths:
                            cyc_paths.append(path)

        self.cyclic_paths = []
        for path in cyc_paths:
            path = path[:-1]                 # remove last element (repeated as the first one)
            min_val   = min(path)            # find minimum value
            min_index = path.index(min_val)  # find position of minimum value
            path = path[min_index:]+path[:min_index+1]
            self.cyclic_paths.append(path)

    def get_critical_latencies (self):
        max_latency    = 0   # maximum latency per iteration
        min_iters      = 0   # minimum number of iterations for cyclic path
        path_latencies = []  # (latency,iters) of cyclic paths

        recurrent_paths = self.cyclic_paths
        for path in recurrent_paths:
            latency = sum( self.instruction_list[i].latency for i in path[:-1] )
            iters   = sum( a >= b       for a,b in zip(path[:-1], path[1:]) )
            latency_iter = latency / iters
            path_latencies.append((latency, iters))
            if latency_iter > max_latency:
                max_latency = latency_iter
            min_iters = max( iters, min_iters )

        return (max_latency, min_iters, path_latencies)

    def show_graphviz(  self, 
                        instrs       = None,
                        num_iters    = 0,
                        show_internal= False,
                        show_latency = False,
                        show_small   = False,
                        show_full    = False 
                        ) -> str:
      
        def escape_html(text: str) -> str:
            """Escape HTML special characters for Graphviz HTML-like labels."""
            return text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')

        colors = ["lightblue", "greenyellow", "lightyellow", 
                  "lightpink", "lightgrey",   "lightcyan", "lightcoral"]

        self.load_instruction_list(instrs)

        # conditional branches: dashed conditional instructions, one edge per possible producer
        # (labeled with its probability) and dotted control edges (not data dependences)
        branches     = self.conditional_branches()
        alternatives = self.producer_alternatives() if branches else {}
        exec_probs   = self.execution_probabilities() if branches else None
        conditional  = {j for i, k in branches for j in range(i + 1, i + 1 + k)}

        recurrent_paths = self.cyclic_paths

        # max_latency    = maximum latency per iteration
        # min_iters      = minimum number of iterations for cyclic path
        # path_latencies = [ (latency,iters), (,) .. ]  of cyclic paths
        max_latency, min_iters, path_latencies = self.get_critical_latencies() 

        max_iters = max (min_iters, num_iters)

        out  = "digraph \"Data Dependence Graph\" {\n  rankdir=\"LR\"; splines=spline; newrank=true;\n"
        out += "  edge [fontname=\"courier\"; color=black; penwidth=1.5; fontcolor=blue];\n"

        # generate clusters of nodes: one cluster per loop iteration
        for iter_id in range(1, max_iters+1):
            out += f" subgraph cluster_{iter_id} "
            out +=  "{\n  style=\"filled,rounded\"; color=blue; "
            out += f"tooltip=\"Loop Iteration #{iter_id}\"; fillcolor={colors[iter_id-1]};\n"
            out +=  "  node [style=filled, shape=rect, fillcolor=lightgrey,"
            out +=  " margin=\"0.05,0\", fontname=\"courier\"];\n"

            for inst_id in range(self.n):
                if show_internal or (inst_id in self.inst_cyclic):
                  lat = self.instruction_list[inst_id].latency
                  txt = escape_html(self.instruction_list[inst_id].text)
                  out += f"  i{iter_id}s{inst_id} ["
                  if inst_id in conditional:
                    out += "style=\"filled,dashed\", "
                  out +=  "label=<<B>"
                  if show_latency:
                    out += f"<FONT COLOR=\"red\">({lat})</FONT> "
                  out += f"{inst_id}"
                  if inst_id in conditional:
                    out += f" <FONT COLOR=\"gray30\">[p={exec_probs[inst_id]:.2f}]</FONT>"
                  if show_small:
                    out += f"</B>>, tooltip=\"{txt}\"];\n"
                  else:
                    out += f": {txt}</B>>,tooltip=\"instruction\"];\n"

            out +=  "}\n"

    
        # generate cluster of input variables
        out += " subgraph inVAR {\n"
        out += "  node[style=box, color=invis, fixedsize=false, fontname=\"courier\"];\n"

        if show_full and show_internal:
          for const_id in range( len(self.constants) ):
             var = self.constants[const_id]
             out += f"  Const{const_id} [label=<<B>{var}</B>>, tooltip=\"constant\", fontcolor=grey];\n"

        if show_full and show_internal:
          for RdOnly_id in range( len(self.read_only) ):
             var = self.read_only[RdOnly_id]
             out += f"  RdOnly{RdOnly_id} [label=<<B>{var}</B>>, tooltip=\"read-only\", fontcolor=green];\n"

        for LoopCar_id in range( len(self.loop_carried) ):
           (inst_id,var) = self.loop_carried[LoopCar_id]
           cyclic = inst_id in self.inst_cyclic
           if show_internal or cyclic:
               out += f"  LoopCar{LoopCar_id} [label=<<B>{var}</B>>, tooltip=\"loop-recurrent\", "
               if cyclic:
                   out += "fontcolor=red];\n"
               else:
                   out += "fontcolor=blue];\n"

        out += " }\n"

        out += " { rank=min; "
                
        if show_full and show_internal:
          for const_id in range( len(self.constants) ):
             out += f"Const{const_id}; "

        if show_full and show_internal:
          for RdOnly_id in range( len(self.read_only) ):
             out += f"RdOnly{RdOnly_id}; "

        for LoopCar_id in range( len(self.loop_carried) ):
           (inst_id,_) = self.loop_carried[LoopCar_id]
           cyclic = inst_id in self.inst_cyclic
           if show_internal or cyclic:
             out += f"LoopCar{LoopCar_id}; "

        out += " }\n\n"


        # generate cluster of output variables
        out += " subgraph outVAR {\n"
        out += "  node [style=box, color=invis, fontcolor=red, fixedsize=false, fontname=\"courier\"];\n"

        for LoopCar_id in range( len(self.loop_carried) ):
           (inst_id,var) = self.loop_carried[LoopCar_id]
           cyclic = inst_id in self.inst_cyclic
           if show_internal or cyclic:
               out += f"  OutCar{LoopCar_id} "
               if cyclic:
                   out += f"[label=<<B>{var}"
                   if show_latency:
                      # Find all paths containing inst_id and get their ratios, then take the max
                      paths_with_inst = [(p, path_latencies[p]) for p in range(len(recurrent_paths)) if inst_id in recurrent_paths[p]]
                      (lat, iters) = max(paths_with_inst, key=lambda x: x[1][0] / x[1][1] if x[1][1] != 0 else float('inf'))[1]
                      if iters==1:
                        out += f" : <FONT COLOR=\"blue\">{lat} cycles/iter</FONT>"
                      else:
                        out += f" : <FONT COLOR=\"blue\">{lat}/{iters}= {lat/iters} cycles/iter</FONT>"
                   out += f"</B>>, tooltip=\"cyclic path\"];\n"
               else:
                   out += f"[label=<<B>{var}</B>>, tooltip=\"not cyclic\", fontcolor=blue];\n"
        out += " }\n"

        out += " { rank=max; "
        for LoopCar_id in range( len(self.loop_carried) ):
           (inst_id,_) = self.loop_carried[LoopCar_id]
           cyclic = inst_id in self.inst_cyclic
           if show_internal or cyclic:
               out += f"OutCar{LoopCar_id}; "

        out += " }\n\n"


        # generate dependence links: initial and intermediate
        for iter_id in range(1, max_iters+1):
          for inst_id in range(self.n):
            for dep in self.inst_dependence_list[inst_id]:

              i_id = dep[0]
              var  = dep[1]

              if i_id == -1:  # inst_id depends on Constant
                if show_full and show_internal:
                  out += f"  Const{var} -> i{iter_id}s{inst_id}[color=grey,tooltip=\"depends on constant\"];\n"
                continue

              if i_id == -3:  # inst_id depends on Read-Only variable
                if show_full and show_internal:
                  label  = self.variables[var]
                  RdOnly_id = self.read_only.index(label)
                  out += f"  RdOnly{RdOnly_id} -> i{iter_id}s{inst_id}[color=green,tooltip=\"depends on read-only variable\"];\n"
                continue

              # inst_id depends on "normal" variable
              alts = alternatives.get((inst_id, self.variables[var])) if alternatives else None
              if alts:
                  name = self.variables[var]
                  for (w, d, prob) in alts:
                      src_iter = iter_id - d
                      if src_iter >= 1:
                          src = f"i{src_iter}s{w}"
                      else:
                          lc = next((n for n, (_, lc_var) in enumerate(self.loop_carried) if lc_var == name), None)
                          if lc is None:
                              continue
                          src = f"LoopCar{lc}"
                      recurrent = inst_id in self.inst_cyclic and w in self.inst_cyclic
                      if not (recurrent or show_internal):
                          continue
                      certain = prob >= 0.995
                      text  = "" if show_small and certain else (name if certain else f"{name} {prob:.2f}")
                      style = ("color=red, penwidth=2.0, " if recurrent else "") + ("" if certain else "style=dashed, ")
                      before = "" if d == 0 else f" of {d} iteration(s) before"
                      out += f"  {src} -> i{iter_id}s{inst_id} [label=\"{text}\", {style}"
                      out += f"tooltip=\"{name}: produced by instruction {w}{before} with probability {prob:.2f}\"];\n"
                  continue
              # Check if current dependence is a part of a cyclical path
              in_cyclic   = inst_id in self.inst_cyclic
              out_cyclic  = i_id    in self.inst_cyclic 
              is_recurrent= in_cyclic and out_cyclic

              if is_recurrent:
                  arrow = "color=red, penwidth=2.0"
              else:
                  arrow = ""

              if inst_id > i_id: ## Not loop-carried
                  in_var = f"i{iter_id}s{i_id}"
                  if show_small:
                    label = ""
                  else:
                    label = self.variables[var]
              else:   ## Loop-carried
                  if iter_id == 1: # first loop iteration
                      var = self.variables[var]
                      for LoopCar_id in range( len(self.loop_carried) ):
                          (_,lc_var) = self.loop_carried[LoopCar_id]
                          if var == lc_var:
                             in_var = f"LoopCar{LoopCar_id}"
                             break
                      label  = ""
                  else:
                      in_var = f"i{iter_id-1}s{i_id}"
                      if show_small:
                          label = ""
                      else:
                          label  = self.variables[var]

              if is_recurrent:
                  out += f"  {in_var} -> i{iter_id}s{inst_id} [label=\"{label}\","
                  out += f" labeltooltip=\"dependence variable: {label}\","
                  out += f" tooltip=\"dependence on cyclical path\", {arrow}];\n"
              elif show_internal:
                  out += f"  {in_var} -> i{iter_id}s{inst_id} [label=\"{label}\","
                  out += f" labeltooltip=\"dependence variable: {label}\","
                  out += f" tooltip=\"not on cyclical path\", {arrow}];\n"

        # control edges of the conditional branches (speculated: not data dependences)
        if show_internal:
            for iter_id in range(1, max_iters + 1):
                for b, k in branches:
                    prob = self.instruction_list[b].prob
                    for j in range(b + 1, b + 1 + k):
                        out += f"  i{iter_id}s{b} -> i{iter_id}s{j} [style=dotted, color=gray45, arrowhead=onormal, "
                        out += f"constraint=false, tooltip=\"control (speculated, not a data dependence): "
                        out += f"skipped when the branch is taken (p={prob:.2f})\"];\n"

        # generate dependence links to loop-carried variables in final iteration
        for LoopCar_id in range( len(self.loop_carried) ):
           (prod_id,_) = self.loop_carried[LoopCar_id]
           cyclic      = prod_id in self.inst_cyclic
           if cyclic:
               out += f"  i{max_iters}s{prod_id} -> OutCar{LoopCar_id}[color=red, penwidth=2.0,tooltip=\"cyclic output dependence\"];\n"
           elif show_internal:
               out += f"  i{max_iters}s{prod_id} -> OutCar{LoopCar_id}[color=blue, penwidth=2.0, tooltip=\"non-cyclic output dependence\"];\n"

        return out + "}\n"

    def get_performance_analysis(self, processJSON) -> dict:

        process = Process.from_json(processJSON)
        self.load_instruction_list(process.instruction_list)

        analysis = { "name": getattr(process, 'name', '') }
        
        dw = process.dispatch
        rw = process.retire

        all_ports = 0
        for instr in self.instruction_list:
            all_ports |= instr.ports

        # list of used ports and number of used ports
        used_ports = [i for i in range(32) if (all_ports >> i) & 1]
        n_ports = len(used_ports)

        # conditional branches: each instruction counts with its probability of being executed
        branches = self.conditional_branches()
        weights  = self.execution_probabilities() if branches else None
        expected = sum(weights) if branches else self.n

        dw_cycles = expected / dw
        rw_cycles = expected / rw

        def throughput_time(w):
            # throughput bound when instruction i is executed w[i] times per iteration
            groups = self.relevant_port_groups(used_ports, w)
            return max([sum(w) / dw, sum(w) / rw] + [g["cycles"] for g in groups])

        # max_latency    = maximum latency per iteration
        max_latency, *_ = self.get_critical_latencies()
        if branches:
            # range: with all the conditional blocks executed, and with none of them
            skipped = {j for i, k in branches for j in range(i + 1, i + 1 + k)}
            reduced = Program()
            reduced.load_instruction_list([d for j, d in enumerate(process.instruction_list) if j not in skipped])
            without_blocks, *_ = reduced.get_critical_latencies()
            with_blocks = max_latency
            analysis["LatencyRange"] = {"with_blocks": with_blocks, "without_blocks": without_blocks,
                                        "min": min(with_blocks, without_blocks),
                                        "max": max(with_blocks, without_blocks)}
            max_latency = min(with_blocks, without_blocks)
            # throughput: with every conditional block executed, and with none of them
            # (informative: the bound uses the expected number of executed instructions)
            t_with    = throughput_time([1.0] * self.n)
            t_without = throughput_time([0.0 if j in skipped else 1.0 for j in range(self.n)])
            analysis["ThroughputRange"] = {"with_blocks": t_with, "without_blocks": t_without,
                                           "min": min(t_with, t_without), "max": max(t_with, t_without)}

        port_groups = self.relevant_port_groups(used_ports, weights)
        port_cycles = max((g["cycles"] for g in port_groups), default=0)
        max_cycles  = max(port_cycles, dw_cycles, rw_cycles)

        analysis["LatencyTime"]=    max_latency 
        analysis["ThroughputTime"]= max_cycles

        cycles_limit = max_cycles
        if (max_latency > max_cycles):
            analysis["performance-bound"] = "LATENCY"
            cycles_limit = max_latency
        elif (max_latency < max_cycles):
            analysis["performance-bound"] = "THROUGHPUT"
        else:
            analysis["performance-bound"] = "LATENCY+THROUGHPUT"
        
        analysis["BestTime"] = cycles_limit

        if branches:
            # Cost of a misprediction: the instructions after the branch are not useful from its
            # dispatch until it resolves (resolution latency, approximated by the dependence chain
            # that computes its condition) plus the branch penalty of the processor
            info, mispredictions, mispredict_time = [], 0.0, 0.0
            for i, k in branches:
                inst = self.instruction_list[i]
                estimated = inst.mispredict is None
                rate = self.predictor_misprediction_rate(inst.prob) if estimated else inst.mispredict
                resolution = self.resolution_latency(i)
                mispredictions  += weights[i] * rate
                mispredict_time += weights[i] * rate * (resolution + process.bPenalty)
                info.append({"index": i, "skip": k, "prob": inst.prob, "mispredict": rate,
                             "estimated": estimated, "exec_prob": weights[i], "resolution": resolution,
                             "cost": resolution + process.bPenalty})
            analysis["Branches"] = info
            analysis["ExecProbability"] = weights
            analysis["MispredictionsPerIter"] = mispredictions
            analysis["BranchPenalty"] = process.bPenalty
            analysis["MispredictTime"] = mispredict_time
            analysis["EstimatedTime"] = cycles_limit + mispredict_time

        # Throughput bound of every relevant resource. Each entry:
        #   resource:     "Dispatch", "Retire" or "Ports"
        #   ports:        port numbers (only for "Ports")
        #   instructions: indices of the instructions that can only use the resource
        #   excluded:     instructions that can use some of its ports but also other ports:
        #                 [{"index": i, "other_ports": [...]}]
        #   throughput:   instructions per cycle of the resource (width or number of ports)
        #   cycles:       len(instructions) / throughput  (cycles per iteration)
        #   bottleneck:   True when cycles is the throughput bound
        all_instrs = list(range(self.n))
        #   expected:     instructions executed per iteration (each one with its probability)
        bounds = [
            {"resource": "Dispatch", "ports": [], "instructions": all_instrs, "excluded": [],
             "throughput": dw, "cycles": dw_cycles, "expected": expected},
            {"resource": "Retire", "ports": [], "instructions": all_instrs, "excluded": [],
             "throughput": rw, "cycles": rw_cycles, "expected": expected},
        ] + [dict(resource="Ports", **g) for g in port_groups]
        for b in bounds:
            b["bottleneck"] = b["cycles"] == max_cycles
        analysis["Throughput-Bounds"] = bounds

        # Latency bound of every cyclic (loop-carried) dependence chain. Each entry:
        #   variable:     variable regenerated by the chain (destination of its last instruction)
        #   instructions: chain of instruction indices, in dependence order
        #   latencies:    latency of each instruction of the chain
        #   iterations:   loop iterations spanned by the chain
        #   cycles:       sum(latencies) / iterations  (cycles per iteration)
        #   bottleneck:   True when cycles is the latency bound
        latency_bounds = []
        for path in self.cyclic_paths:
            chain     = path[:-1]
            latencies = [self.instruction_list[i].latency for i in chain]
            iters     = sum(a >= b for a, b in zip(path[:-1], path[1:]))
            cycles    = sum(latencies) / iters
            latency_bounds.append({
                "variable":     self.instruction_list[chain[-1]].destin,
                "instructions": chain,
                "latencies":    latencies,
                "iterations":   iters,
                "cycles":       cycles,
                "bottleneck":   cycles == max_latency,
            })
        analysis["Latency-Bounds"] = latency_bounds

        return json.dumps(analysis, indent=2)

    def relevant_port_groups(self, used_ports, weights=None):
        # Port subsets S worth evaluating (methodology of the performance-analysis guide):
        #  - every used port on its own (even if no instruction is restricted to it);
        #  - combinations of 2 or more ports that are exactly the union of the ports of the
        #    instructions restricted to S, and whose port sets overlap (connected), e.g.
        #    {P2,P3} + {P0,P2} -> {P0,P2,P3}.
        # Other subsets never give a higher bound than these ones.
        from itertools import combinations

        groups = []
        for r in range(1, len(used_ports) + 1):
            for subset in combinations(used_ports, r):
                mask = 0
                for p in subset:
                    mask |= (1 << p)
                inside   = [i for i, ins in enumerate(self.instruction_list)
                            if ins.ports and (mask & ins.ports) == ins.ports]
                excluded = [i for i, ins in enumerate(self.instruction_list)
                            if (mask & ins.ports) and (mask & ins.ports) != ins.ports]

                if r > 1:
                    port_sets = {self.instruction_list[i].ports for i in inside}
                    union = 0
                    for s in port_sets:
                        union |= s
                    if union != mask or not self._overlapping(port_sets):
                        continue

                groups.append({
                    "ports":        list(subset),
                    "instructions": inside,
                    "excluded":     [{"index": i,
                                      "other_ports": [p for p in range(32)
                                                      if (self.instruction_list[i].ports & ~mask) >> p & 1]}
                                     for i in excluded],
                    "throughput":   r,
                    "expected":     sum(weights[i] for i in inside) if weights else len(inside),
                    "cycles":       (sum(weights[i] for i in inside) if weights else len(inside)) / r,
                })
        return groups

    @staticmethod
    def _overlapping(port_sets):
        # True when the port sets form a single group linked by shared ports
        sets = list(port_sets)
        if not sets:
            return False
        group, pending = sets[0], sets[1:]
        changed = True
        while changed and pending:
            changed = False
            for s in list(pending):
                if s & group:
                    group |= s
                    pending.remove(s)
                    changed = True
        return not pending

_program = Program()
